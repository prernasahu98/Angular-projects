export class Todo {

    constructor(
        public text: string,
        public completed: boolean = false,
        public status: string,
    ) { }
}